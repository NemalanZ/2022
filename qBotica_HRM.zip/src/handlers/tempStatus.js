function setTempStatus(status){
    return localStorage.setItem("status",JSON.stringify(status))
}
function clearTempStatus(){
    return localStorage.removeItem("tempStatus")
}
function getTempStatus(){
    return JSON.parse(localStorage.getItem("tempStatus"))
}


export {setTempStatus,clearTempStatus,getTempStatus}