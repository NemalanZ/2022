
//main
import Dashboard from '../MainPage/Main/Dashboard';
//Pages
import ProfilePage from '../MainPage/Pages/Profile';

import Pages from '../MainPage/Pages/Pages';
//Administrator
import Administrator from '../MainPage/Administration';

export default [
   {
      path: 'main',
      component: Dashboard
   },
   {
      path: 'profile',
      component: ProfilePage
   },
   {
      path: 'pages',
      component: Pages
   },
   {
      path: 'administrator',
      component: Administrator
   }
]