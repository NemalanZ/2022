/**
 * Tables Routes
 */
import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';

import Requisition from "./Jobs/requisition"
import CreateRequisition from './Jobs/create-requisition';
import UpdateRequisition from './Jobs/update-requisition'

import RequisitionExternal from "./Jobs/RequisitionExternal";

import CandidateList from "./Jobs/candidatelist"
import CreateCandidate from './Jobs/create_candidate';
import UpdateCandidate from './Jobs/update-candidate';

import CandidateListExternal from './Jobs/candidatelistExternal';
import CreateCandidateExternal from './Jobs/create_candidateExternal';
import UpdateCandidateExternal from './Jobs/update-candidateExternal';

import JobDetails from "./Jobs/jobdetails"
import JobDetailsExternal from "./Jobs/jobdetailsExternal";

import CandidateProfile from './Jobs/candidateprofile';

import ManageResumes from "./Jobs/manageresumes"

import ShortlistCandidate from "./Jobs/shortlistcandidates"


const Uiinterfaceroute = ({ match }) => (
    <Switch>
        {/* <Redirect exact from={`${match.url}/`} to={`${match.url}/users`} /> */}

        <Route path={`${match.url}/requisition`} component={Requisition} />
        <Route path={`${match.url}/create-requisition`} component={CreateRequisition} />
        <Route path={`${match.url}/update-requisition/:id`} children={<UpdateRequisition />} />

        <Route path={`${match.url}/requisition-external`} component={RequisitionExternal} />

        <Route path={`${match.url}/candidates`} component={CandidateList} />
        <Route path={`${match.url}/add-candidate`} component={CreateCandidate} />
        <Route path={`${match.url}/update-candidate/:id`} children={<UpdateCandidate />} />

        <Route path={`${match.url}/candidates-external`} component={CandidateListExternal} />
        <Route path={`${match.url}/add-candidate-external`} component={CreateCandidateExternal} />
        <Route path={`${match.url}/update-candidate-external/:id`} children={<UpdateCandidateExternal />} />

        <Route path={`${match.url}/job-details/:id`} children={<JobDetails />} />
        <Route path={`${match.url}/job-details-external/:id`} children={<JobDetailsExternal />} />

        <Route path={`${match.url}/candidate-profile/:id`} children={<CandidateProfile />} />

        <Route path={`${match.url}/manage-resumes`} component={ManageResumes} />

        <Route path={`${match.url}/shortlist-candidates`} component={ShortlistCandidate} />
    </Switch>
);

export default Uiinterfaceroute;
