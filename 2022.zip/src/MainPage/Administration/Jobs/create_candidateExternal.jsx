//CreateCandidateExternal

import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import axios, { Axios } from "axios";
import { useForm, Controller, set } from "react-hook-form";

const CreateCandidateExternal = (props) => {
  const [values, setValues] = useState({
    firstName: "",
    lastName: "",
    emailId: "",
    phone: "",
    role: "",
    Experience: "",
    mainSkill: "",
    secondarySkill: "",
    state: "",
    city: "",
  });


  const url = "http://localhost:9000/candidatelist";
  const CandidateSubmit = async (e) => {
    e.preventDefault();
    await axios.post(url, { values });
    props.history.push("/app/administrator/candidates-external");
    if (values.firstName === "") {
      return setError('error', {
        message: "The required field is empty"
      })
    }

  };

  useEffect(() => {
    CandidateSubmit();
  }, []);

  const onFormFieldChange = (e) => {
    setValues({
      ...values,
      [e.target.name]: e.target.value,
    });
  };
  return (
    <div className="page-wrapper">
      <Helmet>
        <title>Create Candidate - qBotica</title>
        <meta name="description" content="Login page" />
      </Helmet>
      {/* Page Content */}
      <div className="content container-fluid">
        <div className="row">
          <div className="col-md-8 offset-md-2">
            {/* Page Header */}
            <div className="page-header">
              <div className="row">
                <div className="col-sm-12">
                  <h3 className="page-title">Candidate</h3>
                </div>
              </div>
            </div>
            {/* /Page Header */}
            <form onSubmit={CandidateSubmit}>
              <div className="row">
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>
                      First Name
                    </label>
                    <input
                      name="firstName"
                      className="form-control"
                      type="text"
                      value={values.firstName}
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Last Name</label>
                    <input
                      name="lastName"
                      value={values.lastName}
                      className="form-control "
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      name="emailId"
                      value={values.emailId}
                      className="form-control "
                      type="email"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Phone</label>
                    <input
                      name="phone"
                      value={values.phone}
                      className="form-control"
                      type="number"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
              <div className="col-sm-6">
                  <div className="form-group">
                    <label>Job Role</label>
                    <input
                      name="role"
                      value={values.role}
                      className="form-control "
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Year of Experience</label>
                    <input
                      name="Experience"
                      value={values.Experience}
                      className="form-control"
                      type="number"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Main Skill</label>
                    <input
                      name="mainSkill"
                      value={values.mainSkill}
                      className="form-control"
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>Secondary Skill</label>
                    <input
                      name="secondarySkill"
                      value={values.secondarySkill}
                      className="form-control"
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>State</label>
                    <input
                      name="state"
                      value={values.state}
                      className="form-control"
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
                <div className="col-sm-6">
                  <div className="form-group">
                    <label>City</label>
                    <input
                      name="city"
                      value={values.city}
                      className="form-control"
                      type="text"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12">
                  <div className="form-group">
                    <label>Resume</label>
                    <input
                      name="file"
                      // value={values.phone}
                      className="form-control"
                      type="file"
                      onChange={onFormFieldChange}
                    />
                  </div>
                </div>
              </div>
              <div className="submit-section">
                <button className="btn btn-primary submit-btn">Save</button>
              </div>
            </form>
          </div>
        </div>
      </div >
      {/* /Page Content */}
    </div >
  );
};

export default CreateCandidateExternal;