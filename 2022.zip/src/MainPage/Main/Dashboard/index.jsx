/**
 * Crm Routes
 */
/* eslint-disable */
import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import Requisition from '../../Administration/Jobs/requisition';
import Employeedashboard from './employeedashboard';
import JobsDashboard from './jobs_dashboard';

const DashboardRoute = ({ match }) => (
   <Switch>
      <Redirect exact from={`${match.url}/`} to={`${match.url}/dashboard`} />
      {/* <Route path={`${match.url}/dashboard`} component={JobsDashboard} /> */}
      <Route path={`${match.url}/dashboard`} component={Requisition} />
      <Route path={`${match.url}/employee-dashboard`} component={Employeedashboard} />
   </Switch>

);

export default DashboardRoute;
